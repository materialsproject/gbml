#define Rprintf  printf    // RJN
#define printe   printf    // RJN
#define warning  printf    // RJN

