void spreplot(double *xev, double *coef, double *sv, Sint *cell, double *x, double *res,
       double *se, double *wpc, double *sca, Sint *m, Sint *nvc, Sint *mi, double *dp,
       Sint *mg, Sint *dv, Sint *nd, Sint *sty, Sint *where, char **what, void **bs);
