int predict(char *filename, int nPredictions, double *descriptors, double *predictions);
