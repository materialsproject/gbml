"""
Predict bulk (K) and shear (G) moduli using gbml (GBM-Locfit).
Queries MP db for specified material(s), computes descriptors, and calls gbml.core.predict().
"""

from pymatgen.core.periodic_table import Element
from pymatgen.core.composition import Composition
from pymatgen.matproj.rest import MPRester
import gbml.core # GBM-Locfit core module
import json
import math
import numpy as np
import os

__author__ = 'Randy Notestine'
__copyright__ = 'Copyright 2015, The Materials Project'
__version__ = '0.9'
__maintainer__ = 'Randy Notestine'
__email__ = 'RNotestine@ucsd.edu'
__date__ = 'September 10, 2015'

API_KEY = None
CAVEAT_AIAB = 'Unable to estimate cohesive energy for material.'
CAVEAT_F_BLOCK = 'Predictions are likely less reliable for materials containing F-block elements.'
CAVEAT_HUBBARD = 'Predictions may be less reliable for materials with non-GGA runs.'
DATAFILE_AIAB = 'data/element_aiab_energy.json'
DATAFILE_K = 'data/gbml-k-v0.9.data'
DATAFILE_G = 'data/gbml-g-v0.9.data'

def get_element_aiab_energy(element):
    """
    Lookup atom-in-a-box (aiab) energy for specified element.
    Used to estimate cohesive energy of a compound from the compound's VASP energy.
    The elemental atom-in-a-box energies were provided by Wei Chen and Maarten de Jong.
    Returns atom-in-a-box energy for specified element.
    :param element:
    :return: aiab_energy
    """

    element_aiab_energy_dict = None

    try:
        with open(os.path.join(os.path.dirname(__file__),DATAFILE_AIAB),'r') as json_file:
            element_aiab_energy_dict = json.load(json_file)

    finally:
        if element_aiab_energy_dict is None:
            return None

        object = element_aiab_energy_dict.get(element)
        if object is not None:
            return object[0]

        return None


def predict_k_g_list(material_id_list):
    """
    Predict bulk (K) and shear (G) moduli for a list of materials.
    :param material_id_list: list of material-ID strings
    :return: (matid_list, predicted_k_list, predicted_g_list, caveats_list)
    Note that len(matid_list) may be less than len(material_id_list),
    if any requested material-IDs are not found.
    """

    if len(material_id_list) == 0 or not isinstance(material_id_list, list):
        return (None, None, None, None)  # material_id_list not properly specified

    lvpa_list = []
    cepa_list = []
    zwal_list = []
    xwsd_list = []
    xwsdl_list = []
    matid_list = []
    k_list = []
    g_list = []
    caveats_list = []
    aiab_problem_list = []

    with MPRester(api_key=API_KEY) as mpr:
        for entry in mpr.query(criteria={"task_id": {"$in": material_id_list}}, properties=
            ["material_id", "pretty_formula", "nsites", "volume", "energy_per_atom", "is_hubbard"]):

            caveats_str = ''
            aiab_flag = False
            f_block_flag = False
            weight_list = []
            energy_list = []
            x_list = []
            z_list = []

            # Construct per-element lists for this material
            composition = Composition(str(entry["pretty_formula"]))
            for element_key, amount in composition.get_el_amt_dict().iteritems():
                element = Element(element_key)
                weight_list.append(composition.get_atomic_fraction(element))
                aiab_energy = get_element_aiab_energy(element_key)  # aiab = atom-in-a-box
                if aiab_energy is None:
                    aiab_flag = True
                    break
                energy_list.append(aiab_energy)
                if element.block == 'f':
                  f_block_flag = True
                x_list.append(element.X)
                z_list.append(element.Z)

            # On error, add material to aiab_problem_list and continue with next material
            if aiab_flag:
                aiab_problem_list.append(str(entry["material_id"]))
                continue

            # Check caveats
            if bool(entry["is_hubbard"]):
                if len(caveats_str) > 0: caveats_str += " "
                caveats_str += CAVEAT_HUBBARD
            if f_block_flag:
                if len(caveats_str) > 0: caveats_str += " "
                caveats_str += CAVEAT_F_BLOCK

            # Calculate intermediate weighted averages (WA) for this material
            ewa = np.average(energy_list, weights=weight_list)      # atom-in-a-box energy WA
            xwa = np.average(x_list, weights=weight_list)           # electronegativity WA
            xwal = np.average(np.log(x_list), weights=weight_list)  # log(electronegativity) WA

            # Append descriptors for this material to descriptor lists
            lvpa_list.append(math.log(float(entry["volume"]) / float(entry["nsites"])))
            cepa_list.append(float(entry["energy_per_atom"]) - ewa)
            zwal_list.append(np.average(np.log(z_list), weights=weight_list))
            xwsd_list.append(math.sqrt(np.average( (x_list - xwa)**2, weights=weight_list)))
            xwsdl_list.append(math.sqrt(np.average( (np.log(x_list) - xwal)**2, weights=weight_list)))
            matid_list.append(str(entry["material_id"]))
            caveats_list.append(caveats_str)

    # Check that at least one valid material was provided
    num_predictions = len(matid_list)
    if num_predictions > 0:
        # Construct descriptor arrays
        if (len(lvpa_list) != num_predictions or len(cepa_list) != num_predictions or
            len(zwal_list) != num_predictions or len(xwsd_list) != num_predictions or
            len(xwsdl_list) != num_predictions):
                return (None, None, None, None)
        k_descriptors = np.ascontiguousarray([lvpa_list, cepa_list, zwal_list, xwsdl_list],
            dtype=float)
        g_descriptors = np.ascontiguousarray([lvpa_list, cepa_list, zwal_list, xwsd_list],
            dtype=float)

        # Allocate prediction arrays
        k_predictions = np.empty(num_predictions)
        g_predictions = np.empty(num_predictions)

        # Make predictions
        k_filename = os.path.join(os.path.dirname(__file__),DATAFILE_K)
        g_filename = os.path.join(os.path.dirname(__file__),DATAFILE_G)
        gbml.core.predict(k_filename, num_predictions, k_descriptors, k_predictions)
        gbml.core.predict(g_filename, num_predictions, g_descriptors, g_predictions)

        k_list = np.exp(k_predictions).tolist()
        g_list = np.exp(g_predictions).tolist()

    # Append aiab problem cases
    for entry in aiab_problem_list:
        matid_list.append(entry)
        k_list.append(None)
        g_list.append(None)
        caveats_list.append(CAVEAT_AIAB)

    if len(matid_list) == 0:
        return (None, None, None, None)
    else:
        return (matid_list, k_list, g_list, caveats_list)


def predict_k_g(material_id):
    """
    Predict bulk (K) and shear (G) moduli for one material.
    :param material_id: material-ID string
    :return: (predicted_k, predicted_g, caveats)
    Note that None may be returned for predicted_k and predicted_g when caveats is not None.
    """

    if len(material_id) == 0 or not isinstance(material_id, str):
        return (None, None, None)  # material_id not properly specified

    (material_id_list, k_list, g_list, caveats_list) = predict_k_g_list([material_id])

    if material_id_list is None:
        return (None, None, None)  # material_id not found in MP db

    return (k_list[0], g_list[0], caveats_list[0])
